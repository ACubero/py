import sys
sys.path.insert(1,'..')
print(sys.path)

from saludos import *
s = Saludo()