def despedir():
    print("Adiós! Me estoy despidiendo desde la función despedir() del módulo")

def saludar():
    print("Hola! Te estoy saludando desde la función saludar() del módulo")